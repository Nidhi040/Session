/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.basic;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Nidhi
 */
public class FirstServlet extends HttpServlet {

    
    public void init() throws ServletException{
        
        System.out.println("-------------------------------");
        System.out.println("Init method is called");
        System.out.println("-------------------------------");
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String name=request.getParameter("name");
        
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("welcome"+name+"<br/><br/>");
        
        HttpSession session = request.getSession();
        String sessionId = session.getId();
        out.println("FirstServlet Session ID is "+ sessionId);
        session.setAttribute("Username",name);
        session.setAttribute("Role","Admin");
        
        out.println("<a href='SecondServlet'>Visit SecondServlet</a>");
        
        out.close();
    }

    public void destroy(){
        
        System.out.println("---------------------------------");
        System.out.println("In destroy method of FirstServlet");
        System.out.println("---------------------------------");
    }
   
}
