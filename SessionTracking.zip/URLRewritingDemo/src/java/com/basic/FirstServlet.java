/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.basic;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Nidhi
 */
public class FirstServlet extends HttpServlet {

    public void init() throws ServletException{
        
        System.out.println("-------------------------------");
        System.out.println("Init method is called");
        System.out.println("-------------------------------");
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
              
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        
        String username=request.getParameter("username");
        out.println("welcome"+username+"<br/><br/>");

        out.println("<a href='SecondServlet?uname=" + username+ "'>Visit:</a>");
        out.close();
    }
    
    public void destroy(){
        
        System.out.println("---------------------------------");
        System.out.println("In destroy method of FirstServlet");
        System.out.println("---------------------------------");
    }
}
